import SwiftUI
import AppKit

class ClipboardManager: ObservableObject {
    @Published private var clipboardHistory: [String] = []
    private let pasteboard = NSPasteboard.general
    private var lastChangeCount: Int
    @AppStorage("maxHistoryItems") private var maxHistoryItems = 20
    
    init() {
        lastChangeCount = pasteboard.changeCount
        startMonitoring()
    }
    
    private func startMonitoring() {
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.checkClipboardChanges()
        }
    }
    
    private func checkClipboardChanges() {
        guard pasteboard.changeCount != lastChangeCount else { return }
        lastChangeCount = pasteboard.changeCount
        
        if let newString = pasteboard.string(forType: .string),
           !clipboardHistory.contains(newString) {
            clipboardHistory.insert(newString, at: 0)
            if clipboardHistory.count > maxHistoryItems {
                clipboardHistory.removeLast()
            }
        }
    }
    
    func getClipboardHistory() -> [String] {
        return clipboardHistory
    }
    
    func pasteItem(_ item: String) {
        pasteboard.clearContents()
        pasteboard.setString(item, forType: .string)
        simulateCmdV()
    }
    
    private func simulateCmdV() {
        let source = CGEventSource(stateID: .combinedSessionState)
        
        let cmdDown = CGEvent(keyboardEventSource: source, virtualKey: 0x37, keyDown: true)
        let vDown = CGEvent(keyboardEventSource: source, virtualKey: 0x09, keyDown: true)
        let vUp = CGEvent(keyboardEventSource: source, virtualKey: 0x09, keyDown: false)
        let cmdUp = CGEvent(keyboardEventSource: source, virtualKey: 0x37, keyDown: false)
        
        cmdDown?.flags = .maskCommand
        vDown?.flags = .maskCommand
        vUp?.flags = .maskCommand
        
        cmdDown?.post(tap: .cgAnnotatedSessionEventTap)
        vDown?.post(tap: .cgAnnotatedSessionEventTap)
        vUp?.post(tap: .cgAnnotatedSessionEventTap)
        cmdUp?.post(tap: .cgAnnotatedSessionEventTap)
    }
}
