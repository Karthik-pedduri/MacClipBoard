import SwiftUI

struct ContentView: View {
    @StateObject var clipboardManager = ClipboardManager()
    
    var body: some View {
        List(clipboardManager.getClipboardHistory(), id: \.self) { item in
            Text(item)
                .onTapGesture {
                    clipboardManager.pasteItem(item)
                }
        }
    }
}
