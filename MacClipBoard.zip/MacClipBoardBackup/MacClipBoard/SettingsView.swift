import SwiftUI

struct SettingsView: View {
    @AppStorage("maxHistoryItems") private var maxHistoryItems = 20
    @AppStorage("shortcutModifiers") private var shortcutModifiers = 768 // Cmd+Option
    @AppStorage("shortcutKeyCode") private var shortcutKeyCode = 9 // V key
    
    var body: some View {
        Form {
            Section(header: Text("Clipboard History")) {
                Stepper("Max History Items: \(maxHistoryItems)", value: $maxHistoryItems, in: 5...100)
            }
            
            Section(header: Text("Global Shortcut")) {
                HStack {
                    Text("Current Shortcut:")
                    KeyboardShortcutView(modifiers: shortcutModifiers, keyCode: shortcutKeyCode)
                }
                Button("Change Shortcut") {
                    // TODO: Implement shortcut recording
                }
            }
        }
        .padding()
        .frame(width: 300, height: 200)
    }
}

struct KeyboardShortcutView: View {
    let modifiers: Int
    let keyCode: Int
    
    var body: some View {
        HStack {
            if modifiers & 256 != 0 { Text("⌘") }
            if modifiers & 512 != 0 { Text("⌥") }
            if modifiers & 1024 != 0 { Text("⌃") }
            if modifiers & 2048 != 0 { Text("⇧") }
            Text(keyCodeToString(keyCode))
        }
    }
    
    private func keyCodeToString(_ keyCode: Int) -> String {
        switch keyCode {
        case 0: return "A"
        case 11: return "B"
        case 8: return "C"
        case 2: return "D"
        case 14: return "E"
        case 3: return "F"
        case 5: return "G"
        case 4: return "H"
        case 34: return "I"
        case 38: return "J"
        case 40: return "K"
        case 37: return "L"
        case 46: return "M"
        case 45: return "N"
        case 31: return "O"
        case 35: return "P"
        case 12: return "Q"
        case 15: return "R"
        case 1: return "S"
        case 17: return "T"
        case 32: return "U"
        case 9: return "V"
        case 13: return "W"
        case 7: return "X"
        case 16: return "Y"
        case 6: return "Z"
        default: return "Unknown"
        }
    }
}
