import SwiftUI

struct ClipboardHistoryView: View {
    @ObservedObject var clipboardManager: ClipboardManager
    @Binding var isPresented: Bool
    
    var body: some View {
        VStack {
            ForEach(clipboardManager.getClipboardHistory(), id: \.self) { item in
                Button(action: {
                    clipboardManager.pasteItem(item)
                    isPresented = false
                }) {
                    Text(item)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 5)
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding()
        .background(Color(NSColor.windowBackgroundColor))
        .cornerRadius(10)
        .shadow(radius: 5)
    }
}
