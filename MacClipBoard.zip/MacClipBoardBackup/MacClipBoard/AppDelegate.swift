import AppKit
import SwiftUI
import HotKey

extension Notification.Name {
    static let openClipboardHistory = Notification.Name("openClipboardHistory")
    static let openSettings = Notification.Name("openSettings")
}


class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBar: StatusBarController?
    var clipboardManager: ClipboardManager?
    var hotKey: HotKey?
    var clipboardHistoryPanel: NSPanel?
    var settingsWindow: NSWindow?
    
    @AppStorage("maxHistoryItems") private var maxHistoryItems = 20
    @AppStorage("shortcutModifiers") private var shortcutModifiers = 768 // Cmd+Option
    @AppStorage("shortcutKeyCode") private var shortcutKeyCode = 9 // V key
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        checkAccessibilityPermissions()
        clipboardManager = ClipboardManager()
        statusBar = StatusBarController(clipboardManager: clipboardManager!)
        setupGlobalShortcut()
    }
    
    func setupGlobalShortcut() {
        hotKey = HotKey(keyCombo: KeyCombo(carbonKeyCode: UInt32(shortcutKeyCode), carbonModifiers: UInt32(shortcutModifiers)))
        hotKey?.keyDownHandler = { [weak self] in
            self?.showClipboardHistory()
        }
    }
    
    @objc func showClipboardHistory() {
        if clipboardHistoryPanel == nil {
            clipboardHistoryPanel = NSPanel(
                contentRect: NSRect(x: 100, y: 100, width: 300, height: 400),
                styleMask: [.nonactivatingPanel, .titled, .resizable, .closable, .fullSizeContentView],
                backing: .buffered,
                defer: false)
            clipboardHistoryPanel?.isFloatingPanel = true
            clipboardHistoryPanel?.level = .floating
            
            let contentView = ClipboardHistoryView(clipboardManager: clipboardManager!, isPresented: .constant(true))
            clipboardHistoryPanel?.contentView = NSHostingView(rootView: contentView)
        }
        
        positionPanelNearCursor()
        clipboardHistoryPanel?.makeKeyAndOrderFront(nil)
    }
    
    func positionPanelNearCursor() {
        if let screenFrame = NSScreen.main?.visibleFrame,
           let panelFrame = clipboardHistoryPanel?.frame {
            let cursorLocation = NSEvent.mouseLocation
            var newOrigin = NSPoint(x: cursorLocation.x, y: cursorLocation.y - panelFrame.height)
            
            // Ensure the panel doesn't go off screen
            if newOrigin.x + panelFrame.width > screenFrame.maxX {
                newOrigin.x = screenFrame.maxX - panelFrame.width
            }
            if newOrigin.y < screenFrame.minY {
                newOrigin.y = cursorLocation.y
            }
            
            clipboardHistoryPanel?.setFrameOrigin(newOrigin)
        }
    }
    
    @objc func showSettings() {
        if settingsWindow == nil {
            let contentView = SettingsView()
            settingsWindow = NSWindow(
                contentRect: NSRect(x: 100, y: 100, width: 300, height: 200),
                styleMask: [.titled, .closable, .miniaturizable, .fullSizeContentView],
                backing: .buffered,
                defer: false)
            settingsWindow?.center()
            settingsWindow?.setFrameAutosaveName("Settings")
            settingsWindow?.contentView = NSHostingView(rootView: contentView)
        }
        settingsWindow?.makeKeyAndOrderFront(nil)
    }

    func checkAccessibilityPermissions() {
        let options: NSDictionary = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true]
        let accessibilityEnabled = AXIsProcessTrustedWithOptions(options)
        
        if !accessibilityEnabled {
            let alert = NSAlert()
            alert.messageText = "Accessibility Permissions Required"
            alert.informativeText = "MacClipboard needs accessibility permissions to function properly. Please grant permission in System Preferences > Security & Privacy > Privacy > Accessibility."
            alert.addButton(withTitle: "Open System Preferences")
            alert.addButton(withTitle: "Cancel")
            
            let response = alert.runModal()
            if response == .alertFirstButtonReturn {
                NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Library/PreferencePanes/Security.prefPane"))
            }
        }
    }
}
